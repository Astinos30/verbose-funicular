# verbose-funicular
"Verbose Funicular" is an immersive VR project that takes you on a thrilling journey through a futuristic city. Explore skyscrapers, solve puzzles, and unravel mysteries in this captivating virtual world. Get ready for a mind-bending adventure like no other. Grab your VR headset and let the exploration begin!
